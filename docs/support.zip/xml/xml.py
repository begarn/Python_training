UTILISER e-tree

CREER UN FICHIER XML
On veut créer le fichier d la forme :

<series>
	<nom titre="Docteur_who" lang="fr">
		<personnage>Docteur Who</personnage>
		<personnage>Rose Tyler</personnage>
		<personnage>Mickey Smith</personnage>
	</nom>
	<nom titre="game_Of_Throne" lang="en">
		<personnage etat="mort">Eddard Stark</personnage>
		<personnage etat="mort">Joffrey Baratheon</personnage>
		.
		.
		<personnage etat="mort">Margaery Tyrell</personnage>
	</nom>
</series>

Télécharger
xml.etree.ElementTree est natif dans Python, mais lxml est basé sur libxml2 et libxslt écrites en C et très rapides. 
Télécharger et installez libxml2-2.7.8.win32.zip sur ftp://ftp.zlatkovic.com/libxml

OU faire simplement : pip install lxml


[etree-creer-xml.py]

from lxml import etree

# Racine
root = etree.Element('series')

# Elément nom avec ses attributs
serie = etree.SubElement(root,'nom')
serie.set('lang','fr') #attribut
serie.set('titre','game_Of_Throne') #attribut

# Element personnage
personnages = ['Docteur Who', 'Rose Tyler', 'Mickey Smith']
for perso in personnages:
	personnage = etree.SubElement(serie, 'personnage')
	personnage.text = perso
	
# Obtenir le fichier
try:
	with open('series.xml','w') as fic:
		fic.write(etree.tostring(root, pretty_print=True).decode('utf-8'))

except IOError:
	print('Problème lors de l\'écriture....')
	exit(1)


LIRE UN FICHIER XML	
On veut lire le fichier suivant :

<series>
	<nom titre="Docteur_who" lang="fr">
		<personnage>Docteur Who</personnage>
		<personnage>Rose Tyler</personnage>
		<personnage>Mickey Smith</personnage>
	</nom>
	.
	.
</series>	

[ etree-lire-xml.py ]

Exemple de code :
from lxml import etree

# Charger
tree = etree.parse('series.xml')

# Naviguer avec XPath
# Le contenu d'un noeu est accessible via l'attribut text
# get() donne l'attribut au sens XML, par exemple lang
for node in tree.xpath('//series/nom'):
	print('Série {} en {}:'.format(node.get('titre'), node.get('lang')))
	for perso in node.xpath('personnage'):
		print('   {}'.format(perso.text))


Autres :
Récup du doctype du document : doctype = tree.docinfo.doctype
Récup du neoud racine : root = tree.getroot()
Liste des attributs ou des valeurs d'un tag :
for node in tree.xpath('//personnage'):
	print(node.items()) # liste des attributs
	print(node.text) # liste des valeurs





	
VALIDER UN FICHIER XML

On charge d'abord le document.
>>> with open('document.xml') as fichier:
		t = etree.parse(fichier)
		
>>> t.getroot()

On veut valider via un schéma XSD qu'il faut charger aussi :
>>> with open('document.xsd','r') as fichier:
		xsd = etree.XMLSchema(etree.parse(fichier))

Valider :
>>> xsd.validate(tree)
True
>>> xsd.validate(t.getroot())
True




2. DOM

a. Lecture [dom-lecture.py]

Les interpréteurs Python disposent d’une implémentation de parseur DOM appelée minidom. Celle-ci permet de mettre en œuvre très rapidement la lecture d’un fichier XML.

Prenons un exemple de mise en œuvre de ce module avec la lecture du contenu XML suivant :

<Voiture nom='delorean'>  
  <Proprietaire>Emmett Brown</Proprietaire>  
  <Equipements>  
    <Equipement type='Convecteur temporel' />  
    <Equipement type='Générateur à fusion' />  
  </Equipements>  
</Voiture>


La première étape va être de demander au module minidom d’analyser le XML afin d’en établir un modèle en mémoire. Cette étape va se faire à l’aide d’une méthode parse(), qui analyse un contenu XML à partir d’un fichier, ou d’une méthode parseString(), qui fait la même chose à partir d’une chaîne de caractères :


# Changer cet import en parseString en fonction du besoin.  
from xml.dom.minidom import parse  
  
# Analyse du fichier donné et assignation du résultat   
# dans une variable.  
mon_XML = parse('voiture.xml')


À ce stade, le contenu XML est en mémoire, prêt à être analysé. Il existe deux grandes approches pour récupérer les données XML provenant de cet analyseur DOM. Bien sûr, ces méthodes ne sont pas exclusives et peuvent être mélangées selon les besoins.


b. Méthode par accès direct

Cette méthode permet d’accéder directement à des éléments XML spécifiques. Ci-après, un exemple avec l’accès à l’élément Equipement :


# Import de la méthode parse().  
from xml.dom.minidom import parse  
  
# Analyse du fichier XML.  
mon_XML = parse('voiture.xml')  
  
# Récupération dans une liste des éléments XML  
# dont la balise se nomme ’Equipement’.  
liste_des_equipements = mon_XML.getElementsByTagName('Equipement') 
  
# Parcours de cette liste.  
for equipement in liste_des_equipements:  
    # Affichage de l’attribut ’type’ de l’équipement en question. 
    print(equipement.getAttribute('type'))


Grâce à l’accès direct, le temps de parcours de l’arbre est constant, quelle que soit la taille de l’arbre : on sait où on va et comment y aller, donc pas besoin de parcourir toutes les branches à la recherche du ou des éléments désirés.



c. Méthode par analyse hiérarchique

Cette méthode est basée sur le principe d’une analyse du contenu XML par examens successifs de sa hiérarchie, c’est-à-dire des enfants, frères et parents des nœuds qui composent l’arbre XML. L’analyse hiérarchique parcourt les différents nœuds de l’arbre, revenant en arrière si elle tombe dans un cul-de-sac. 

from xml.dom.minidom import parse  
  
# Analyse du fichier XML.  
mon_XML = parse('voiture.xml')  

# Récupération de la racine de l’arbre,   
# c’est-à-dire du premier nœud.  
racine_du_XML = mon_XML.childNodes[0]  
  
# À partir de ce nœud, on peut lire l’attribut ’nom’...  
nom_voiture = racine_du_XML.getAttribute('nom')  

# ... puis l’afficher.  
print(nom_voiture)  
>>> delorean  
  
# On récupère les fils du nœud racine.  
liste_des_fils = racine_du_XML.childNodes  

# On parcourt ces fils.  
for fils in liste_des_fils:  
    # On s’assure que le nœud est bien un élément, et non pas   
    # autre chose, comme un commentaire ou du contenu.  
    if fils.ELEMENT_NODE != fils.nodeType:  
        continue  
		
    # Si le nœud porte le nom ’Proprietaire’...  
    if 'Proprietaire' == fils.nodeName:  
        # ... on récupère le premier fils, c’est-à-dire le nœud 
        # représentant le texte.  
        nom = fils.firstChild  
		
        # On vérifie que le nœud existe et, s’il s’agit bien d’un 
        # nœud de type TEXT_NODE, c’est-à-dire du texte écrit   
        # entre une balise ouvrante et une balise fermante...  
        if None != nom and nom.TEXT_NODE == nom.nodeType:  
            # ... on affiche le texte du nœud.  
            print(nom.data) # (1)  
			
    # Si le nœud porte le nom ’Equipements’...  
    elif 'Equipements' == fils.nodeName:  
        # ... on récupère les fils de ce nœud.  
        liste_des_equipements = fils.childNodes  
       
	   # On parcourt ces fils.  
        for equipement in liste_des_equipements:  
            # On s’assure qu’il s’agit bien d’un ELEMENT_NODE.  
            if equipement.ELEMENT_NODE != equipement.nodeType:  
                continue  
            
			# Si le nœud porte le nom ’Equipement’...  
            if 'Equipement' == equipement.nodeName:  
                # ... on récupère l’attribut nommé ’type’...  
                type = equipement.getAttribute('type')  
                
				# ... et on l’affiche.  
                print(type) # (2)  
  
>>> Emmett Brown    # (1)  
Convecteur temporel # (2)  
Générateur à fusion





d. Écriture

En plus des outils pour lire des fichiers XML, le module minidom dispose aussi de quoi sauvegarder des données (on dit aussi les sérialiser). Dans le cas d’un fichier XML déjà en mémoire, l’opération pourra se faire très simplement à travers une méthode de génération d’une chaîne de caractères proposée par minidom. 

Exemple dans lequel un fichier XML est ouvert et un élément modifié, afin d’être regénéré sous la forme d’une chaîne de caractères.

[ dom-ecriture.py]

from xml.dom.minidom import parse  
  
# Analyse du fichier XML.  
mon_XML = parse('voiture.xml')  
  
# Récupération du nœud ’Propriétaire’  
proprietaire = mon_XML.getElementsByTagName('Proprietaire')  
  
# Modification du texte du premier (et unique) fils.  
proprietaire[0].firstChild.data = 'Doc Emmett Brown'  
  
# Affichage du nouveau contenu XML ’propre’ (avec indentation 
# et retours à la ligne).  
print(mon_XML.toprettyxml()) 
 
>>> <?xml version="1.0" ?>  
<Voiture nom="delorean">  
  
    <Proprietaire>Doc Emmett Brown</Proprietaire> # Le nom a bien 
                                                  # été changé. 
  
    <Equipements>  
           <Equipement type="Convecteur temporel"/>  
           <Equipement type="Generateur à fusion"/>  
    </Equipements>  
</Voiture>



L’autre méthode, très pratique, permet de passer directement par un descripteur de fichier afin que le contenu XML soit écrit dans un fichier, plutôt que dans une chaîne de caractères. Voici une reprise de l’exemple précédent où le contenu XML est modifié, puis écrit dans son fichier d’origine qui est écrasé.


from xml.dom.minidom import parse  
import sys  
  
chemin_du_fichier = 'voiture.xml'  
  
# Analyse du fichier XML.  
mon_XML = parse(chemin_du_fichier)  
  
# Récupération du nœud ’Propriétaire’.  
proprietaire = mon_XML.getElementsByTagName('Proprietaire')  
  
# Modification du texte du premier (et unique) fils.  
proprietaire[0].firstChild.data = 'Doc Emmett Brown'  
  
try:  
    # Ouverture du fichier en écriture.  
    fichier_XML = open(chemin_du_fichier) 
	
    # Écriture du nouveau contenu XML  
    mon_XML.writexml(fichier_XML) 

    # Fermeture du fichier.  
    fichier_XML.close()  
except:  
    print('Erreur: ', sys.exc_info()[0]) 

	
	
	
	
	
	
	
3. SAX
a. Lecture

L’autre méthode de traitement des fichiers XML, le SAX, fait aussi l’objet d’un module intégré par défaut dans les interpréteurs Python. 

Cette méthode est basée sur une gestion par événements de la lecture d’un contenu XML : à chaque lecture d’un élément XML, une méthode est appelée. L’implémentation se fait à travers la classe ContentHandler, dont il est nécessaire d’hériter afin de surcharger les méthodes liées aux événements de lecture. Cette classe ContentHandler contient une liste de méthodes qui seront appelées par le module SAX, selon le type d’élément courant à analyser.

Par exemple, lorsque l’analyseur SAX détecte un élément ouvrant, il appelle la méthode startElement() ; lorsqu’il détecte un élément fermant, il appelle la méthode endElement(), etc.

Dans l’exemple suivant, très simple, la surcharge de la méthode startElement() permet de récupérer les événements de détection d’un nouvel élément XML avec ses attributs. La surcharge de la méthode characters() permet, quant à elle, de récupérer les sections de texte d’un arbre XML. Cet événement est appelé sur tous les caractères présents, hors et dans des éléments, il est donc nécessaire de filtrer pour éliminer les chaînes vides. Cela fait, il faut passer, à l’analyseur SAX, le chemin d’accès au fichier XML ainsi que l’implémentation d’un gestionnaire de contenu.



import xml.sax  
  
# Spécialisation de la classe ContentHandler chargée   
# d’appeler certaines méthodes en fonction de l’élément XML   
# actuellement parsé.  
class MonHandlerSAX(xml.sax.ContentHandler):  
    def __init__(self):  
        super(MonHandlerSAX, self).__init__()  
  
    # Méthode appelée à l’ouverture d’une balise XML.   
    # Les paramètres sont le nom de la balise et la liste   
    # de ses attributs.  
    def startElement(self, name, attrs):  
        # On affiche le nom.  
        print('Element', name)
		
        # Pour chaque attribut...  
        for (cle, valeur) in attrs.items():  
            # ... on affiche son nom et sa valeur.  
            print('  Attribut :', cle, "=", valeur)  
  
    # Méthode appelée lorsque le parseur en est à un élément texte 
    # compris entre une balise ouvrante et sa contrepartie  
    # fermante. Le paramètre est le texte en question.  
    def characters(self, content):  
        # strip() permet d’ôter les caractères blancs en début  
        # et fin de chaîne. Si, une fois ces blancs retirés,   
        # la chaîne n’est pas vide...  
        if content.strip():  
            # ... on l’affiche.  
            print("  Texte :", content)  
  
# Instanciation de la classe ContentHandler personnalisé   
# en fonction des besoins.  
mon_handler = MonHandlerSAX() 
  
# Analyse du fichier XML.  
xml.sax.parse('voiture.xml', mon_handler)  

>>> Element Voiture  
  Attribut : nom = delorean  
Element Proprietaire  
  Texte : Emmett Brown  
Element Equipements  
Element Equipement  
  Attribut : type = Convecteur temporel  
Element Equipement  
  Attribut : type = Generateur à fusion
  
  
  
  
  
  
b. Écriture

Il n’existe pas de classe permettant d’écrire du contenu XML à partir d’une hiérarchie de classes. 
  
  
  
  



