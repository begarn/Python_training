from xml.dom.minidom import parse  
import sys  
  
chemin_du_fichier = 'voiture.xml'  
  
# Analyse du fichier XML.  
mon_XML = parse(chemin_du_fichier)  
  
# Récupération du nœud ’Propriétaire’.  
proprietaire = mon_XML.getElementsByTagName('Proprietaire')  
  
# Modification du texte du premier (et unique) fils.  
proprietaire[0].firstChild.data = 'Doc Emmett Brown'  
  
try:  
    # Ouverture du fichier en écriture.  
    fichier_XML = open(chemin_du_fichier) 
	
    # Écriture du nouveau contenu XML  
    mon_XML.writexml(fichier_XML) 
	
    # Fermeture du fichier.  
    fichier_XML.close()  
except:  
    print('Erreur: ', sys.exc_info()[0]) 