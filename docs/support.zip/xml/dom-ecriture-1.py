from xml.dom.minidom import parse  
  
# Analyse du fichier XML.  
mon_XML = parse('voiture.xml')  
  
# Récupération du nœud ’Propriétaire’  
proprietaire = mon_XML.getElementsByTagName('Proprietaire')  
  
# Modification du texte du premier (et unique) fils.  
proprietaire[0].firstChild.data = 'Doc Emmett Brown'  
  
# Affichage du nouveau contenu XML ’propre’ (avec indentation 
# et retours à la ligne).  
print(mon_XML.toprettyxml()) 