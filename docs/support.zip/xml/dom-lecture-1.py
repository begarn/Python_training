# Import de la méthode parse(). 
from xml.dom.minidom import parse

# Analyse du fichier XML.  
mon_XML = parse('voiture.xml')  
	
# Récupération dans une liste des éléments XML  
# dont la balise se nomme ’Equipement’.  
liste_des_equipements = mon_XML.getElementsByTagName('Equipement') 
  
# Parcours de cette liste.  
for equipement in liste_des_equipements:  
    # Affichage de l’attribut ’type’ de l’équipement en question. 
    print(equipement.getAttribute('type'))