from lxml import etree

# Charger
tree = etree.parse('series-INIT.xml')

# Naviguer avec XPath
# Le contenu d'un noeu est accessible via l'attribut text
# get() donne l'attribut au sens XML, par exemple lang
for node in tree.xpath('//series/nom'):
	print('Série {} en {}:'.format(node.get('titre'), node.get('lang')))
	for perso in node.xpath('personnage'):
		print('   {}'.format(perso.text))