from lxml import etree

# Racine
root = etree.Element('series')

# Elément nom avec ses attributs
serie = etree.SubElement(root,'nom')
serie.set('lang','fr') #attribut
serie.set('titre','game_Of_Throne') #attribut

# Element personnage
personnages = ['Docteur Who', 'Rose Tyler', 'Mickey Smith']
for perso in personnages:
	personnage = etree.SubElement(serie, 'personnage')
	personnage.set('etat','mort') #attribut
	personnage.text = perso
	
# Obtenir le fichier
try:
	with open('series.xml','w') as fic:
		fic.write(etree.tostring(root, pretty_print=True).decode('utf-8'))

except IOError:
	print('Problème lors de l\'écriture....')
	exit(1)