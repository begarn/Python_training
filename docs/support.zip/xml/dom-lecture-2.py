from xml.dom.minidom import parse  
  
# Analyse du fichier XML.  
mon_XML = parse('voiture.xml')  

# Récupération de la racine de l’arbre,   
# c’est-à-dire du premier nœud.  
racine_du_XML = mon_XML.childNodes[0]  
  
# À partir de ce nœud, on peut lire l’attribut ’nom’...  
nom_voiture = racine_du_XML.getAttribute('nom')  

# ... puis l’afficher.  
print(nom_voiture)   
  
# On récupère les fils du nœud racine.  
liste_des_fils = racine_du_XML.childNodes  

# On parcourt ces fils.  
for fils in liste_des_fils:  
    # On s’assure que le nœud est bien un élément, et non pas   
    # autre chose, comme un commentaire ou du contenu.  
    if fils.ELEMENT_NODE != fils.nodeType:  
        continue  
		
    # Si le nœud porte le nom ’Proprietaire’...  
    if 'Proprietaire' == fils.nodeName:  
        # ... on récupère le premier fils, c’est-à-dire le nœud 
        # représentant le texte.  
        nom = fils.firstChild  
		
        # On vérifie que le nœud existe et, s’il s’agit bien d’un 
        # nœud de type TEXT_NODE, c’est-à-dire du texte écrit   
        # entre une balise ouvrante et une balise fermante...  
        if None != nom and nom.TEXT_NODE == nom.nodeType:  
            # ... on affiche le texte du nœud.  
            print(nom.data) # (1)  
			
    # Si le nœud porte le nom ’Equipements’...  
    elif 'Equipements' == fils.nodeName:  
        # ... on récupère les fils de ce nœud.  
        liste_des_equipements = fils.childNodes  
       
	   # On parcourt ces fils.  
        for equipement in liste_des_equipements:  
            # On s’assure qu’il s’agit bien d’un ELEMENT_NODE.  
            if equipement.ELEMENT_NODE != equipement.nodeType:  
                continue  
            
			# Si le nœud porte le nom ’Equipement’...  
            if 'Equipement' == equipement.nodeName:  
                # ... on récupère l’attribut nommé ’type’...  
                type = equipement.getAttribute('type')  
                
				# ... et on l’affiche.  
                print(type) # (2)  