#!/usr/bin/python3
 
import http.server

# Paramètres serveur
PORT = 8888
server_address = ("", PORT)

# Objet HTTPServer
server = http.server.HTTPServer

# Traitement des requêtes et repertoire CGI
handler = http.server.CGIHTTPRequestHandler
handler.cgi_directories = ["/"]
print("Serveur actif sur le port :", PORT)

# Création du serveur web
httpd = server(server_address, handler)
httpd.serve_forever() # Loop