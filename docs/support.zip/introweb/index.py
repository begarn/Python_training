#!/usr/bin/python3
# -*- coding: utf-8 -*
import cgi
import sys
import cgitb
cgitb.enable()
#sys.path.insert(0, "c:\stage")

# Traitement des champs
form = cgi.FieldStorage()
print("Content-type: text/html; charset=utf-8\n")

# Récupérer les saisies
print(form.getvalue("nom"))
print(form.getvalue("prenom"))
print(form.getvalue("email"))

html = """<!doctype html>
<head>
    <title>Ma première page</title>
</head>
<body>
    <form action="/index.py" method="post">
        Nom :<input type="text" name="nom" value="" /><br>
		Prenom :<input type="text" name="prenom" value="" /><br>
		Email :<input type="email" name="email" value="" /><br>
        <input type="submit" name="send" value="Envoyer">
    </form> 
</body>
</html>
"""

# Sortie
print(html)