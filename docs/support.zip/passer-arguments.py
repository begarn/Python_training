#passer.py
import sys

# Chaque argument de ligne de commande passé au programme 
# est ajouté à sys.argv, qui est un objet liste. 
for arg in sys.argv: 
    print (arg)

# Le premier argument  
print(sys.argv[1])

# Aller plus loin : 
# (docopt, getopt, argparse, etc.)
# http://sametmax.com/la-plus-belle-maniere-de-parser-les-arguments-de-script-en-python/