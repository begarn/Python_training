##################################################
# CLASSE  PartieBataille                                 #  
# Qui va gérer l'ensemble                     #
##################################################

#PartieBataille
#- joueur1
#- joueur2
#- jeu
#+ demarrerPartie
#- paquet
#- melanger()
#- distribuer()
#- main()
#- bataille()
#+ finPartie()



# Elle utilise Joueur et JeuClassique
from Joueur import Joueur
from JeuClassique import JeuClassique

class PartieBataille:
	# création de joueurs et du jeu de cartes
	def __init__(self, joueur): # Un seul joueur, l'autre c'est l'ordi
		self.__joueur = joueur
		self.__ordinateur = Joueur('9000', 'HAL')
		self.__jeu = JeuClassique() # On choisit le jeu baitaille classique
	

	# Démarrer la partie, en mélangeant puis en distribuant
	def demarrerPartie(self):
		self.__melanger()  # méthode privée
		self.__
	# Les deux joueurs jouent tant qu'il leur reste des cartes
	# main() : main ds un jeu de cartes = cartes jouées par l'ensemble des
	# joueurs lors d'un tour
	poursuivre = True
	while poursuivre:
		poursuivre = self.__main() 
	
	# Méthode privée 
	def __melanger(self):
		self.__jeu.melanger()  # Appel de melange() de JeuCartes

	# Méthode privée 
	def __distribuer(self):
		for i in range(len(self.__jeu.cartes)) # i va de 0 à 51 soit 52 cartes
			carte = self.__jeu.tirer()
			
			# Donner les cartes aux joueurs, 26 cartes chacun
			if i % 2 == 0: # pair : donner au joueur
				self.__joueur.ajouterCarte(carte)
			else:
				self.__ordinateur.ajouterCarte(carte)
				
	
	# Méthode privée 
	# Si bataille, la liste reste contiendra les cartes gagnées
	# On pourra réutiliser le code de main(.) en cas de bataille
	def __main(self, reste = []):
		# Chaque joueur tire une carte
		carte_joueur = self.__joueur.tirerCarte()
		carte_ordinateur = self.__ordinateur.tirerCarte()
		
		# Si l'un des deux joueurs n'a plus de cartes, il a perdu
		if carte_joueur is None:
			self.finPartie(self.__joueur, self.__ordinateur)
			return False
		elif carte_ordinateur is None:
			self.finPartie(self.__ordinateur, self.__joueur)
			return False
	
		# Affichage des cartes mises en jeu (la main)
		print('Main :')
		print('   - {} {} : {}'.format(self.__joueur.prenom, self.__joueur.nom, str(carte_joueur)))
		print('   - {} {} : {}'.format(self.__ordinateur.prenom, self.__ordinateur.nom, str(carte_ordinateur)))

		
		# On teste qui a gagné et récupère les cartes
		# Si égalité, on place les cartes mises en jeu dans la liste reste
		# et on appelle la méthode bataille(.)
		if carte_joueur.valeur == carte_ordinateur.valeur:
			# Place les cartes mises en jeu dans la liste reste
			reste.append(carte_joueur)
			reste.append(carte_ordinateur)
			return self.__bataille(reste)
		elif carte_joueur.valeur > carte_ordinateur.valeur:
			# Le joueur rrafle la mise : on lui ajoute les cartes
			self.__joueur.ajouterCarte(carte_joueur)
			self.__joueur.ajouterCarte(carte_ordinateur)
			print('   {} {} gagne la main'.format(self.__joueur.prenom, self.__joueur.nom, )
		else:
			# C'est l'ordinateur qui gagne
			self.__ordinateur.ajouterCarte(carte_joueur)
			self.__ordinateur.ajouterCarte(carte_ordinateur)
			print('   {} {} gagne la main'.format(self.__joueur.prenom, self.__joueur.nom, )

		# Si les 2 joueurs ont pu jouer, on renvoie la valeur True pour poursuivre
		return True
	
	# En cas de bataille, on rappelle la méthode main(.)
	# en indiquant qu'il y a déjà des cartes en jeu
	# ce mécanisme permet de faire des batailles successives
	# en augmentant simplement le nombre de cartes en jeu
	def __bataille(self, reste):
		print('*** BATAILLE ***')
		return self.__main(reste)
	
	# Qd un joueur a gagné, on met à jour le palmarès des 2 joueurs
	# et on affiche un petit message
	def finpartie(self, perdant, gagnant):
		perdant.defaites += 1
		gagnant.victoires += 1
		print('{} {} a gagné!!'.format(gagnant.prenom, gagnant.nom)