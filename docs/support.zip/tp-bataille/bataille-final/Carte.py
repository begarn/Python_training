##################################################
# CLASSE ABSTRAITE Carte                         #  
# Les attributs seront privés, donc créer        #
# des getters/ setters / property                #
##################################################

class Carte:
	# Attributs statiques à redéfinir dans la classe fille
	valeurs = None
	couleurs = None
	
	def __init__(self, val, coul):
		if self.__class__ is Carte: # if self.__class__ == Carte 
				raise Exception("Construction directe interdite")
			
		# Appel validation(.) pr valider les attributs (méthode statique) 
		self.__class__.validation(val, coul)
		
		# Les données courantes privées
		self.__valeur = val
		self.__couleur = coul
	
	# Méthodes d'accès/modif et property
	def getValeur(self):
		return self.__valeur
		
	def setValeur(self, val):
		self.__valeur = val
		
	valeur = property(getValeur, setValeur)
		
	def getCouleur(self):
		return self.__couleur
		
	def setCouleur(self, coul):
		self.__couleur = coul
		
	couleur = property(getCouleur, setCouleur)
	
	# La méthode validation(.) à redéfinir : elle est statique
	@staticmethod
	def validation(val, coul):
		pass
	
	# Affichage
	def affiche(self):
		# Sortie avec print(.) utilisant les attributs statiques
		print(Carte.valeurs[self.valeur], "de", Carte.couleurs[self.couleur])

	# Affichage
	def affiche_ascii(self):
		# Chaine à afficher (attn : convertir la valeur en chaine)
		nom = str(Carte.valeurs[self.valeur]) + "de" + Carte.couleurs[self.couleur]
		
		# taille de la zone d'affichage
		taille = len(nom) + 2
		
		print("/", "-" * taille, "\\", sep="")
		print("|", "-" * taille, "|", sep="")
		print("|", nom, "|")
		print("|", "-" * taille, "|", sep="")
		print("\\", "-" * taille, "/", sep="")	
	
	# Affichage automatique des instances
	def __str__(self):
		# Obligatoirement un return et une chaine renvoyée	
		return str(Carte.valeurs[self.valeur]) + "de" + Carte.couleurs[self.couleur]