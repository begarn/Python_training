###################################
# TEST DE LA CLASSE Joueur 
###################################	

>>> from Joueur import Joueur
>>> from CarteClassique import CarteClassique
>>> c = CarteClassique(2, 2)
>>> j1.Joueur("Jean", "Dupont")
>>> print(j1)
Jean Dupont
Palmarès: 0 défaite(s) et 0 victoire(s)
>>> j1.ajouterCarte()
>>> print(j)
Jean Dupont
Palmarès: 0 défaite(s) et 0 victoire(s)
2 de Trefle