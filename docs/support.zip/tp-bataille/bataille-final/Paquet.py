###########################################################
# CREER LA CLASSE Paquet HERITANT DE JeuCartes            #
###########################################################

from JeuCartes import JeuCartes # Afin d'utiliser la classe mère

class Paquet(JeuCartes):
	def __init__(self):
		super().__init__(True) # Avec True le paquet (qui est un jeu) est vide
		
	def ajouter(self, carte): # self est le paquet
		""" Ajoute une carte au paquet. 
		    carte est la carte qu'on veut ajouter au paquet
		"""
		self.cartes.append(carte)
		
	def __add__(self, carte):
		self.ajouter(carte)