##################################################
# CLASSE CONCRETE CarteClassique                 #  
# pour le jeu classique de bataille              #
# Cette classe dérive de la classe abstraite     #
# Carte               #
##################################################	
from Carte import Carte # on a besoin de Carte

class CarteClassique(Carte):
	def __init__(self, val, coul):
		# Redéfinir les attributs statiques dans le constructeur
		Carte.valeurs = (None, None, 2, 3, 4, 5, 6, 7, 8, 9, 10, "Valet", "Dame", "Roi", "As")
		Carte.couleurs = ("Coeur", "Carreau", "Trefle", "Pique")
		
		# Constructeur du parent (qui a besoin de 2 paramètres)
		super().__init__(val, coul)
			

	# La méthode validation(.) redéfinie ici, avec décorateur
	@staticmethod
	def validation(val, coul):
		if(val < 2 or val > 14): # Validation de la valeur
			print("Erreur: la valeur d'une carte est entre 2 et 14")
			exit(1) # on sort
		
		if(coul < 0 or val > 3): # Validation de la couleur
			print("Erreur: la couleur d'une carte est entre 0 et 4")
			exit(1) # on sort


	