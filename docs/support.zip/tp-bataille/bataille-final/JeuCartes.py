##################################################
# CLASSE ABSTRAITE JeuCartes                     #  
# 1- Appeler la méthode initialiser()            #
#    qui initialisera le jeu de cartes           #
##################################################

# Classe JeuCartes : JeuCartes.py
""" Classe abstraite utilisée par JeuClassique """

import random

class JeuCartes:
	# constructeur __init__
	def __init__(self, vide = False)
		# L'aspect abstrait
		if self.__class__ is JeuCartes: # if self.__class__ == JeuCartes 
				raise Exception("Construction directe interdite")
		else:
			self.__cartes = [] # Attribut cartes initialisé en liste vide
	
			# Appel de initialiser() pour créer les 52 cartes
			self.initialiser()
	
	
	# L'attribut __cartes de Jeucartes, privé, n'est pas hérité
	# Il faut des méthodes d'accès à __cartes et une propriété
	# setter/getter/property
	def __getCartes(self):
		return self.__cartes
		
	def __setCartes(self, carte):
		if len(self.__cartes > 52):
			raise Exception("Jeu complet")
		self.__cartes = carte

	cartes = property(__getCartes, __setCartes)
	
	
	# Méthode d'affichage
	def __str__(self):
		cartes_du_jeu = "" # variable locale
		for carte in self.cartes:
			if cartes_du_jeu == "":
			  cartes_du_jeu = str(carte)
			else:
			  cartes_du_jeu += "," + str(carte)
			  
		return cartes_du_jeu
	
	def melanger(self):
		""" Mélange des objets qui sont ds l'attribut cartes """
		random.shuffle(self.cartes)

	def tirer(self):
		""" Retire de la liste self.cartes le premier élément """
		try :
			return self.cartes.pop(0)
		except IndexError as error:
			# print(error.args[0]) -> message d'erreur associé à l'exception
			print("Plus de carte dans le jeu de cartes.")
			return None
			
	# Méthode initialiser() définie sans contenu
	def initialiser(self):
		pass