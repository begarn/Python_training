####################################
#
# PROGRAMME PRINCIPAL
#
####################################

from PartieBataille import PartieBataille
from Joueur import Joueur

if __name__ == '__main__'
	joueur_1 = Joueur('Jean', 'Dupont')
	jeu = PartieBataille(joueur_1)
	jeu.demarrerpartie()