#######################################################
# CLASSE CONCRETE JeuClassique                        #  
# 1- appel du constructeur du parent sans paramètre() #
# 2- redéfinir initialiser() de cartes                #
#######################################################	
	
from JeuCartes import JeuCartes  #	La classe abstraite	
from CarteClassique import CarteClassique

class JeuClassique(JeuCartes):
	def __init__(self):
		super().__init__()
			
	# Redéfinition de initialiser()
	def initialiser(self):
		""" Remplir le jeu de cartes des 52 cartes """
			for val in range(2,15):
				for coul i range(4):
					self.cartes.append(CarteClassique(val, coul))	