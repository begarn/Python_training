##################################################
# CLASSE  Joueur                                 #  
# On va gérer son palmarès                       #
##################################################

#Joueur
#- nom
#- prenom
#- victoires
#- defaites
#- paquet      (<-- attribut qui est un objet)
#+ tirerCarte()
#+ ajouterCarte()
#+ __str__()


# Elle utilise Paquet via l'attribut privé paquet
from Paquet import Paquet

class Joueur:
	def __init__(self, nom, prenom):
		self.__nom = nom
		self.__prenom = prenom
		self.__victoires = 0
		self.__defaites = 0
		self.__paquet = Paquet() # Cet attribut est un paquet
		
	# Récup de l'identité du joueur (en lecture seule)
	def getNom(self):
		return self.__nom
	nom = property(getNom)
		
	def getPrenom(self):
		return self.__prenom
	prenom = property(getPrenom)
	
	# Autres getters et setters
	def getVictoires(self):
		return self.__victoires
	
	def setVictoires(self, n):
		self.__victoires = n
	victoires = property(getVictoires, setVictoires)
	
	def getDefaites(self):
		return self.__defaites
	
	def setDefaites(self, n):
		self.__defaites = n
	defaites = property(getDefaites, setDefaites)
	
	# L'objet paquet de  type Paquet
	def getPaquet(self):
		return self.__paquet
	paquet = property(getPaquet)
	
	# La méthode tirerCarte()
	# Le joueur tire la carte de son paquet pour jouer
	# utilise tirer() de Jeucartes dont hérite Paquet
	def tirerCarte(self):
		return self.paquet.tirer()
	
	# La méthode ajouterCarte()
	# En cas de victoire il faut ajouter la carte AU paquet du joueur
	# utilise ajouter() de la classe Paquet
	def ajouterCarte(self, carte):
		self.paquet.ajouter(carte)
		
	# Affichage d'une chaine donnant les infos du joueur
	# La chaine est formatée avec format(.)
	def __str__(self):
		return "{} {}\nPalmarès: {} défaite(s) et {} victoire(s)\n{}".format(self.prenom, self.nom, self.defaites, self.victoires, str(self.paquet)) 