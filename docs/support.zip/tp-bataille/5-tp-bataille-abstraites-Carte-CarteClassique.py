##################################################
# CLASSE ABSTRAITE Carte                         #  
# Les attributs seront privés, donc créer        #
# des getters/ setters / property                #
##################################################

class Carte:
	# Attributs statiques à redéfinir dans la classe fille
	valeurs = None
	couleurs = None
	
	def __init__(self, val, coul):
		if self.__class__ == Carte
				raise Exception("Construction directe interdite")
			
		# Validation de la couleur et valeur via une méthode validation(.)
		self.__class__.validation(val, coul)
		
		# Les données courantes
		self.__valeur = val
		self.__couleur = coul
	
	# Méthodes d'accès/modif et property
	def getValeur(self):
		return self.__valeur
		
	def setValeur(self, val):
		self.__valeur = val
		
	valeur = property(getValeur, setValeur)
		
	def getCouleur(self):
		return self.__couleur
		
	def setCouleur(self, coul):
		self.__couleur = coul
		
	couleur = property(getCouleur, setCouleur)
	
	# La méthode validation(.) à redéfinir, avec décorateur
	@staticmethod
	def validation(val,coul):
		pass
	
	# Affichage
	def affiche(self):
		# Sortie avec print(.) utilisant les attributs statiques
		print(Carte.valeurs[self.valeur], "de", Carte.couleurs[self.couleur])

	# Affichage
	def affiche_ascii(self):
		# Chaine à afficher (aatn : convertir la valeur en chaine)
		nom = str(Carte.valeurs[self.valeur]) + "de" + Carte.couleurs[self.couleur]
		
		# taille de la zone d'affichage
		taille = len(nom) + 2
		
		print("/", "-" * taille, "\\", sep="")
		print("|", "-" * taille, "|", sep="")
		print("|", nom, "|")
		print("|", "-" * taille, "|", sep="")
		print("\\", "-" * taille, "/", sep="")	
	
	# Affichage automatique des instances
	def __str__(self):
		# Obligatoirement un return et une chaine renvoyée	
		return str(Carte.valeurs[self.valeur]) + "de" + Carte.couleurs[self.couleur]
		
		
		
		
		
		
##################################################
# CLASSE CONCRETE CarteClassique                 #  
# pour le jeu classique de bataille              #
# Cette classe dérive de la classe abstraite     #
# Carte                                          #
##################################################	

class CarteClassique(Carte):
	def __init__(self, val, coul):
		# Redéfinir les attributs statiques dans le constructeur
		Carte.valeurs = (None, None, 2, 3, 4, 5, 6, 7, 8, 9, 10, "Valet", "Dame", "Roi", "As")
		Carte.couleurs = ("Coeur", "Carreau", "Trefle", "Pique")
		
		# Constructeur du parent
		super().__init__(val, coul)
			

	# La méthode validation(.) redéfinie ici
	@staticmethod
	def validation(val, coul):
		if(val < 2 or val > 14): # Validation de la valeur
			print("Erreur: la valeur d'une carte est entre 2 et 14")
			exit(1) # on sort
		
		if(coul < 0 or val > 3): # Validation de la couleur
			print("Erreur: la couleur d'une carte est entre 0 et 4")
			exit(1) # on sort


	