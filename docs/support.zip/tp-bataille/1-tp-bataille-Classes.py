
##################################
# LA CLASSE Carte
##################################

# Classe dans le fichier Carte.py
class Carte:
	def __init__(self, val, coul):
		self.valeur = val
		self.couleur = coul
		
# Instancier une carte c1  [ test dans le shell]
>>> from Carte import Carte
>>> c1 = Carte(14, "coeur")	
>>> c1.couleur  # accès à l'attribut public
'coeur'
>>> c1.valeur
14

# Instancier une carte c2, 
>>> c2 = Carte(9, "pique")	
>>> c2.couleur
'pique'
>>> c2.valeur
9


##################################
# LA METHODE affiche(self)
##################################

# Elle va afficher une carte avec print
def affiche(self):
	print(self.valeur, "de", self.couleur)


# Appeler une méthode sur une instance
>>> c1 = Carte(7, "trefle")	
>>> c1.affiche()
7 de trefle


############################################
# VALIDER les données dans le constructeur
# après avoir codé valeur et ouleur des
# cartes
############################################

# Interdire de créer une carte avec un code
# invalide (ex. valeur de 21 et couleur de 6)

class Carte:
	
	def __init__(self, val, coul)
		# Validation de la valeur
		if(val < 2 or val > 14):
			print("Erreur: la valeur d'une carte est entre 2 et 14")
			exit(1) # on sort
			
		# Validation de la couleur
		if(coul < 0 or val > 3):
			print("Erreur: la couleur d'une carte est entre 0 et 4")
			exit(1) # on sort
			
		self.valeur = val
		self.couleur = coul



############################################
# MODIFIER la méthode d'affichage pour 
# pour prendre en compte les codes valeur
# et couleur des cartes
############################################

def affiche(self):
	
	# Initialiser les chaine pr affichage
	affiche_valeur = None
	affiche_couleur = None
	
	# Traitement de la valeur
	if self.valeur <= 10:
		affiche_valeur = self.valeur	
	elif self.valeur <= 11:
		affiche_valeur = "Valet"	
	elif self.valeur <= 12:
		affiche_valeur = "Dame"	
	elif self.valeur <= 13:
		affiche_valeur = "Roi"	
	else:
		affiche_valeur = "As"	
		
	# Traitement de la couleur
	if self.couleur == 0:
		affiche_couleur = "Coeur"
	elif self.couleur == 1:
		affiche_couleur = "Carreau"
	elif self.couleur == 2:
		affiche_couleur = "Trefle"
	elif:
		affiche_couleur = "Pique"
		
	# Sortie avec print(.)	
	print(affiche_valeur, "de", affiche_couleur)
	
	
############################################
# CREER UN ATRIBUT STATIQUE pour stocker les
# codes couleur et valeur et virer toutes if
# dans la méthode affiche()
############################################

class Carte:
	# Attributs statiques valeurs et couleurs 
	# ici sous forme de tuple ()
	valeurs = (None, None, 2, 3, 4, 5, 6, 7, 8, 9, 10, "Valet", "Dame", "Roi", "As")
	couleurs = ("Coeur", "Carreau", "Trefle", "Pique")
	
	def __init__(self, val, coul):
		# Validation de la valeur
		if(val < 2 or val > 14):
			print("Erreur: la valeur d'une carte est entre 2 et 14")
			exit(1) # on sort
			
		# Validation de la couleur
		if(coul < 0 or coul > 3):
			print("Erreur: la couleur d'une carte est entre 0 et 4")
			exit(1) # on sort
			
		self.valeur = val
		self.couleur = coul

	def affiche(self):
		# Sortie avec print(.) utilisant les attributs statiques	
		print(Carte.valeurs[self.valeur], "de", Carte.couleurs[self.couleur])

		
		
############################################
# CREER UNE 2ème méthode d'affichage
############################################	

	def affiche_ascii(self):
		# Chaine à afficher (aatn : convertir la valeur en chaine)
		nom = str(Carte.valeurs[self.valeur]) + "de" + Carte.couleurs[self.couleur]
		
		# taille de la zone d'affichage
		taille = len(nom) + 2
		
		print("/", "-" * taille, "\\", sep="")
		print("|", "-" * taille, "|", sep="")
		print("|", nom, "|")
		print("|", "-" * taille, "|", sep="")
		print("\\", "-" * taille, "/", sep="")



#####################################################
# TESTER les 2 méthodes affiche() et affiche_ascii()
#####################################################		
		
>>> from Carte import Carte
>>> c1 = Carte(11, 1)	
>>> c1.affiche()
Valet de Carreau
>>> c1.affiche_ascii()
/-----------------\
|                 |
|Valet de Carreau |
|                 |
\-----------------/		



#####################################################
# CREER UNE 2ème méthode d'affichage __str__(self)
# appelée automatiquement en printant 1 objet
# => éliminer affiche()
#####################################################

	def __str__(self):
		# Obligatoirement un return et une chaine renvoyée	
		return str(Carte.valeurs[self.valeur]) + "de" + Carte.couleurs[self.couleur]


#####################################################
# TESTER  __str__(self)
#####################################################
>>> from Carte import Carte
>>> c1 = Carte(11, 1)	
>>> print(c1)
Valet de Carreau


#####################################################
# CREER UN FICHIER TEST start.py
# (ou utiliser main.py dans votre IDE PyCharm)
# et tester en lançant le fichier (Run)
#####################################################

from Carte import Carte

if __name__ = "__main__":
	c = Carte(12, 2)
	c2 = Carte(14, 3)
	
	print("Première carte:")
	print(c)
	
	print("\nDeuxième carte:")
	c2.affiche_ascii()
	





####################################################
# FICHIER COMPLET Carte.py                         #
####################################################

class Carte:
	# Attributs statiques valeurs et couleurs 
	# ici sous forme de tuple ()
	valeurs = (None, None, 2, 3, 4, 5, 6, 7, 8, 9, 10, "Valet", "Dame", "Roi", "As")
	couleurs = ("Coeur", "Carreau", "Trefle", "Pique")
	
	def __init__(self, val, coul):
		# Validation de la valeur
		if(val < 2 or val > 14):
			print("Erreur: la valeur d'une carte est entre 2 et 14")
			exit(1) # on sort
			
		# Validation de la couleur
		if(coul < 0 or coul > 3):
			print("Erreur: la couleur d'une carte est entre 0 et 4")
			exit(1) # on sort
			
		self.valeur = val
		self.couleur = coul

	def affiche(self):
		# Sortie avec print(.) utilisant les attributs statiques	
		print(Carte.valeurs[self.valeur], "de", Carte.couleurs[self.couleur])

	def affiche_ascii(self):
		# Chaine à afficher (aatn : convertir la valeur en chaine)
		nom = str(Carte.valeurs[self.valeur]) + "de" + Carte.couleurs[self.couleur]
		
		# taille de la zone d'affichage
		taille = len(nom) + 2
		
		print("/", "-" * taille, "\\", sep="")
		print("|", "-" * taille, "|", sep="")
		print("|", nom, "|")
		print("|", "-" * taille, "|", sep="")
		print("\\", "-" * taille, "/", sep="")	
	def __str__(self):
		# Obligatoirement un return et une chaine renvoyée	
		return str(Carte.valeurs[self.valeur]) + "de" + Carte.couleurs[self.couleur]