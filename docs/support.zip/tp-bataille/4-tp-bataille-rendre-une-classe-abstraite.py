##################################################
# CLASSES "ABSTRAITES"                           #  
# Comment rendre une classe abstraite ?          #
# (empêcher la création d'instances)             #
##################################################

>>> class MaClasse:
...		def _init__(self):
...			print("Constructeur")
...
>>>	objet = MaClasse()
Constructeur
>>> objet.__class__   # __class__ contient le type de la classe (et donc son nom)
<class '__main__.MaClasse'>


# Rendons cette classe abstraite, avec une méthode qui ne fait rien
>>> class MaClasse:
...		def _init__(self):
			if self.__class__ == MaClasse
				raise exception("Construction directe interdite")
			else:
...				print("Constructeur")
...		def methodeSansContenu(self): # A redéfinir dans la classe fille
...			pass
...
>>>	objet = MaClasse()
Exception: Construction directe interdite


# Créons et instancions une classe fille
>>> class ClasseFille(MaClasse):
...		def _init__(self):
...				print("Appel depuis la classe fille")
...				super().__init__()	
...				
...		def methodeSansContenu(self): # Redéfinition
...			print("Appel de la méthode redéfinie")
...
>>>	objet = ClasseFille()
Appel depuis la classe fille
Constructeur