##########################################################
# HERITAGE
##########################################################
# Pour que 2 joueurs s'affrontent, chacun
# doit avoir un paquet de cartes issu du jeu
# Créons la classe Paquet dérivant du JeuCartes


###########################################################
# MODIFIER LE CONSTRUCTEUR DE                             #
# JeuCartes pour donner la possibilité d'avoir un jeu vide#
# (un paquet est bien un jeu vide au début (avant la      #
# distribution des cartes)                                #
###########################################################

def __init__(self, vide = False)
		self.__cartes = [] # Attribut cartes initialisé en liste vide
	
		# Remplir le jeu de cartes des 52 cartes
		if not vide:
			for val in range(2,15):
				for coul i range(4):
					self.__cartes.append(Carte(val, coul))
					

##################################################################
# MODIFIER JeuCartes                                             #         
# 1- AJOUTER DES GETTERS/SETTERS/PROPERTY à                      #
# JeuCartes car ses attributs étant privés, ils ne seront        # 
# pas hérités par Paquet                                                     #
# 2- Remplacer les occurrences de __cartes par la property cartes#
##################################################################

# Classe JeuCartes : JeuCartes.py
""" Classe créant un jeu de cartes """

from Carte import Carte
import random

class JeuCartes:
	# constructeur __init__
	def __init__(self, vide = False)
		self.__cartes = [] # Attribut cartes initialisé en liste vide
	
		# Remplir le jeu de cartes des 52 cartes
		if not vide:
			for val in range(2,15):
				for coul i range(4):
					self.__cartes.append(Carte(val, coul))
	
	
	# L'attribut __cartes de Jeucartes, privé, n'est pas hérité
	# Il faut des méthodes d'accès à __cartes et une propriété
	# setter/getter/property
	def __getCartes(self):
		return self.__cartes
		
	def __setCartes(self, carte):
		if len(self.__cartes > 52):
			raise Exception("Jeu complet")
		self.__cartes = carte

	cartes = property(__getCartes, __setCartes)
	
	
	# Méthode d'affichage
	def __str__(self):
		cartes_du_jeu = "" # variable locale
		for carte in self.cartes:
			if cartes_du_jeu == "":
			  cartes_du_jeu = str(carte)
			else:
			  cartes_du_jeu += "," + str(carte)
			  
		return cartes_du_jeu
	
	
	
	def melanger(self):
		""" Mélange des objets qui sont ds l'attribut cartes """
		random.shuffle(self.cartes)

	def tirer(self):
		""" Retire de la liste self.cartes le premier élément """
		try :
			return self.cartes.pop(0)
		except IndexError as error:
			# print(error.args[0]) -> message d'erreur associé à l'exception
			print("Plus de carte dans le jeu de cartes.")
			return None



###########################################################
# CREER LA CLASSE Paquet HERITANT DE JeuCartes            #
###########################################################

from JeuCartes import JeuCartes # Afin d'utiliser la classe mère

class Paquet(JeuCartes):
	def __init__(self):
		super().__init__(True) # Avec True le paquet (qui est un jeu) est vide
		
	def ajouter(self, carte):  # carte est la carte qu'on veut ajouter au paquet
		""" Ajoute une carte au paquet. """
		self.cartes.append(carte)
	

###########################################################
# TESTER Paquet DANS LA CONSOLE                           #
###########################################################	

>>> from Paquet import Paquet # un paquet vide
>>> p = Paquet()
>>> print(p)

>>> from Carte import Carte
>>> c = Carte(12, 2)
>>> p.ajouter(c)
>>> print(c) 
Dame de Trefle
>>> print(p)
Dame de Trefle

>>> print(p.tirer()) # vérifier l'héritage en tirant du paquet
Dame de Trefle


###########################################################
# SURCHARGER le + DANS Paquet AVEC  __add__(self, other)  #
###########################################################	

from JeuCartes import JeuCartes # Afin d'utiliser la classe mère

class Paquet(JeuCartes):
	def __init__(self):
		super().__init__(True) # Avec True le paquet (qui est un jeu) est vide
		
	def ajouter(self, carte): # self est le paquet
		""" Ajoute une carte au paquet. 
		    carte est la carte qu'on veut ajouter au paquet
		"""
		self.cartes.append(carte)
		
	def __add__(self, carte):
		self.ajouter(carte)


###########################################################
# TESTER L'OPERATEUR + DANS Paquet DANS LA CONSOLE        #
###########################################################	

>>> from Paquet import Paquet # un paquet vide
>>> from Carte import Carte
>>> dame_trefle = Carte(12, 2)
>>> paquet = Paquet()
>>> paquet + dame_trefle # Au lieu de paquet.ajouter(dame_trefle)
>>> print(paquet)
Dame de Trefle

