
##################################
# LA CLASSE JeuCartes
##################################

##############
#  JeuCartes #
##############
# cartes     #
# melanger() #
# tirer()    #
##############


# Classe dans le fichier JeuCartes.py
from Carte import Carte

class JeuCartes:
	""" Classe créant un jeu de cartes """
	def __init__(self)
		self.cartes = [] # Attribut cartes initialisé en liste vide
	
		# Remplir le jeu de cartes des 52 cartes
		for val in range(2,15):
			for coul in range(4):
				self.cartes.append(Carte(val, coul))
	


##############################################
# TEST de la classe JeuCartes dans la console#
##############################################
	
>>> from JeuCartes import JeuCartes
>>> j = JeuCartes()	
>>> print(j.cartes[0])
2 de Coeur
>>> len(j.cartes)
52


####################################################
# AFFICHER toutes les 52 cartes séparées par une   #
# virgule : utiliser __str__(self)                 #
####################################################

# Il suffit d'appeler print() sur l'ensemble des 
# éléments de l'attribut cartes (qui st des cartes)
def __str__(self):
	cartes_du_jeu = "" # variable locale
	for carte in self.cartes:
		if cartes_du_jeu == "":
		  cartes_du_jeu = str(carte)
		else:
		  cartes_du_jeu += "," + str(carte)
		  
	return cartes_du_jeu


##############################################
# TEST : afficher toutes les cartes          #
##############################################

>>> from JeuCartes import JeuCartes
>>> j = JeuCartes()	
>>> print(j)
2 de Coeur, 2 de Carreau, ...., As de Pique


##############################################
# MELANGER UNE LISTE                         #
# Aide sur le module random                  #
##############################################

>>> import random
>>> dir(random)    # fonctions proposées par le module
>>> help(random.shuffle) # Que fait la fonction shuffle
>>> ma_liste = list(range(10))
>>> random.shuffle(ma_liste)  # Mélange la liste



##############################################
# MELANGER LES CARTES DU JEU                 #
# Méthode melanger() de JeuCartes            #
##############################################
from Carte import Carte
import random

class JeuCartes:
	""" Classe créant un jeu de cartes """
	def __init__(self)
		self.cartes = [] # Attribut cartes initialisé en liste vide
	.
	.
	.
	def melanger(self):
		# mélange des objets qui sont ds l'attribut cartes
		random.shuffle(self.cartes)


>>> from jeuCartes import JeuCartes
>>> j = JeuCartes()
>>> j.melanger()
>>> print(j)





##############################################
# TIRER UNE ELEMENT D'UNE LISTE              #
# Aide sur un objet : dir() et help()        #
##############################################

>>> ma_liste = list(range(10))
>>> dir(ma_liste)    # fonctions proposées sur une liste
['__add__', '__class_',..., 'pop', 'remove', 'reverse', 'sort']
>>> help(ma_liste.pop) # Que fait la fonction pop

# pop(0) on dépilera le 1er élément, d'index 0




##############################################
# TIRER UNE CARTE DU JEU                     #
# Méthode tirer() de JeuCartes               #
##############################################
from Carte import Carte
import random

class JeuCartes:
	""" Classe créant un jeu de cartes """
	def __init__(self)
		self.cartes = [] # Attribut cartes initialisé en liste vide
	.
	.
	.
	def melanger(self):
		""" Mélange des objets qui sont ds l'attribut cartes """
		random.shuffle(self.cartes)

	def tirer(self):
		""" Retire de la liste self.cartes le premier élément """
		return self.cartes.pop(0)

		
>>> from jeuCartes import JeuCartes
>>> j = JeuCartes()
>>> j.melanger()
>>> carte = j.tirer()
>>> print(carte)
Valet de Pique



##############################################
# TIRER UNE CARTE DU JEU                     #
# Méthode tirer() de JeuCartes               #
# Jeu vide -> Exception IndexError           #
##############################################
		
from Carte import Carte
import random

class JeuCartes:
	""" Classe créant un jeu de cartes """
	def __init__(self)
		self.cartes = [] # Attribut cartes initialisé en liste vide
	.
	.

	def melanger(self):
		""" Mélange des objets qui sont ds l'attribut cartes """
		random.shuffle(self.cartes)

	def tirer(self):
		""" Retire de la liste self.cartes le premier élément """
		try :
			return self.cartes.pop(0)
		except IndexError as error:
			# print(error.args[0]) -> message d'erreur associé à l'exception
			print("Plus de carte dans le jeu de cartes.")
			return None

		
>>> from jeuCartes import JeuCartes
>>> j = JeuCartes()
>>> j.melanger()
....
>>> carte = j.tirer()
Plus de carte dans le jeu de cartes.




###################################################
# RENDRE LES ATTRIBUTS PRIVES DANS  les classes   #
# Carte et JeuCartes   + setters/getters/property #
###################################################

# Créer une carte sans signification
>>> from Carte import Carte
>>> c = Carte(2, 3)
>>> print(c)
>>> c.valeur = 32 # Cette valeur n'existe pas
>>> c.couleur = "Turquoise" # Cette couleur n'existe pas
>>> print(c) # provoque IndexError


# Donc on doit rendre les attributs privés
# Classe Carte : Carte.py
class Carte:
	# Attributs statiques valeurs et couleurs 
	# ici sous forme de tuple ()
	valeurs = (None, None, 2, 3, 4, 5, 6, 7, 8, 9, 10, "Valet", "Dame", "Roi", "As")
	couleurs = ("Coeur", "Carreau", "Trefle", "Pique")
	
	def __init__(self, val, coul)
		.......
		self.__valeur = val
		self.__couleur = coul

	def affiche(self):
		# Sortie avec print(.) utilisant les attributs statiques	
		print(Carte.valeurs[self.__valeur], "de", Carte.couleurs[self.__couleur])

	def affiche_ascii(self):
		# Chaine à afficher (aatn : convertir la valeur en chaine)
		nom = str(Carte.valeurs[self.__valeur]) + "de" + Carte.couleurs[self.__couleur]
		......
		
	def __str__(self):
		# Obligatoirement un return et une chaine renvoyée	
		return str(Carte.valeurs[self.__valeur]) + "de" + Carte.couleurs[self.__couleur]


	# getters, setters avec property : Exemple
	#def __getValeur(self):
	#	print("Passage dans getValeur")
	#	return self.__valeur
	#	
	#def __setValeur(self, val):
	#	print("Passage dans setValeur")
	#	self.__valeur = val
	#
	#valeur = property(__getValeur, __setValeur)
	
# Classe JeuCartes : JeuCartes.py
""" Classe créant un jeu de cartes """

from Carte import Carte
import random

class JeuCartes:
	def __init__(self)
		self.__cartes = [] # Attribut cartes initialisé en liste vide
	
		# Remplir le jeu de cartes des 52 cartes
		for val in range(2,15):
			for coul i range(4):
				self.__cartes.append(Carte(val, coul))
	
	def __str__(self):
		cartes_du_jeu = "" # variable locale
		for carte in self.__cartes:
			if cartes_du_jeu == "":
			  cartes_du_jeu = str(carte)
			else:
			  cartes_du_jeu += "," + str(carte)
			  
		return cartes_du_jeu
	
	def melanger(self):
		""" Mélange des objets qui sont ds l'attribut cartes """
		random.shuffle(self.__cartes)

	def tirer(self):
		""" Retire de la liste self.cartes le premier élément """
		try :
			return self.__cartes.pop(0)
		except IndexError as error:
			# print(error.args[0]) -> message d'erreur associé à l'exception
			print("Plus de carte dans le jeu de cartes.")
			return None



###################################################
# TESTER AVEC start.py                            #
###################################################			

from Carte import Carte

if __name__ = "__main__"
j = JeuCartes()
j.melanger()
c = j.tirer()
print(c)

