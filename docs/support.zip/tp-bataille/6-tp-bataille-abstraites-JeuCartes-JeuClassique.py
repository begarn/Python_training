##################################################
# CLASSE ABSTRAITE JeuCartes                     #  
# 1- Appeler la méthode initialiser()            #
#    qui initialisera le jeu de cartes           #
##################################################

# Classe JeuCartes : JeuCartes.py
""" Classe abstraite utilisée par JeuClassique """

import random

class JeuCartes:
	# constructeur __init__
	def __init__(self, vide = False)
		self.__cartes = [] # Attribut cartes initialisé en liste vide
	
		# Appel de initialiser()
		self.initialiser()
	
	
	# L'attribut __cartes de Jeucartes, privé, n'est pas hérité
	# Il faut des méthodes d'accès à __cartes et une propriété
	# setter/getter/property
	def __getCartes(self):
		return self.__cartes
		
	def __setCartes(self, carte):
		if len(self.__cartes > 52):
			raise Exception("Jeu complet")
		self.__cartes = carte

	cartes = property(__getCartes, __setCartes)
	
	
	# Méthode d'affichage
	def __str__(self):
		cartes_du_jeu = "" # variable locale
		for carte in self.cartes:
			if cartes_du_jeu == "":
			  cartes_du_jeu = str(carte)
			else:
			  cartes_du_jeu += "," + str(carte)
			  
		return cartes_du_jeu
	
	
	
	def melanger(self):
		""" Mélange des objets qui sont ds l'attribut cartes """
		random.shuffle(self.cartes)

	def tirer(self):
		""" Retire de la liste self.cartes le premier élément """
		try :
			return self.cartes.pop(0)
		except IndexError as error:
			# print(error.args[0]) -> message d'erreur associé à l'exception
			print("Plus de carte dans le jeu de cartes.")
			return None
			
	# Méthode initialiser() définie sans contenu
	def initialiser(self):
		pass
		
		
		
		
		
		
#######################################################
# CLASSE CONCRETE JeuClassique                        #  
# 1- appel du constructeur du parent sans paramètre() #
# 2- redéfinir initialiser() de cartes                #
#######################################################	
	
from JeuCartes import JeuCartes  #	La classe abstraite	
from Carte import Carte

class JeuClassique(JeuCartes):
	# constructeur __init__
	def __init__(self):
		super().__init__()
			
	# Redéfinition de initialiser()
	def initialiser(self):
		""" Remplir le jeu de cartes des 52 cartes """
			for val in range(2,15):
				for coul i range(4):
					self.__cartes.append(Carte(val, coul))	