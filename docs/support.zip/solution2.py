FONCTIONS

1/ Écrire une fonction somme avec un argument « tuple de longueur variable » qui calcule la somme des nombres contenus dans le tuple.

Tester cette fonction par des appels avec différents tuples d’entiers ou de flottants.


"""Fonction : passage d'un tuple."""
# fonction
def somme(*args):
	resultat = 0
	for nombre in args:
		resultat += nombre
	return resultat
	
# programme principal ------------------------------------
print("-"*40)
print(somme(23))
print("\n", "-"*40)
print(somme(-10, 13))
print("\n", "-"*40)
print(somme(23, 42, 13))
print("\n", "-"*40)
print(somme(-10.0, 12))



2) Écrire une autre fonction somme avec trois arguments, et qui renvoie leur somme.

Dans le programme principal, définir un tuple de trois nombres, puis utilisez la syntaxe d’appel à la fonction qui décompresse le tuple. Affichez le résultat.

# -*- coding: UTF-8 -*-
"""Decompression d'un tuple."""
# fonction
def somme(a, b, c):
	return a+b+c

# programme principal ------------------------------
sequence = (2, 4, 6)
print(somme(*sequence))



3) Écrire une fonction unDictionnaire avec un argument « dictionnaire de longueur variable », et qui affiche son argument.

Dans le programme principal, définir un dictionnaire, puis utilisez la syntaxe d’appel à la fonction qui décompresse le dictionnaire. Affichez le résultat.



# -*- coding: UTF-8 -*-
"""Fonction : passage d'un dictionnaire."""
# fonction
def unDictionnaire(**kargs):
	return kargs
	
# programme principal ------------------
print(" appel avec des parametres nommes ")
print(unDictionnaire(a=23, b=42))
print(" appel avec un dictionnaire decompresse ")
mots = {'d':85, 'e':14, 'f':9}
print(unDictionnaire(**mots))



LISTE EN INTENSION


1. Utilisez une liste en compréhension pour ajouter 3 à chaque élément d’une liste d’entiers de 0 à 5.

# -*- coding: UTF-8 -*-
"""Liste en intension.
Forme 1.
"""

# programme principal -----------------------------------------------
result1 = []
for i in range(6):
	result1.append(i+3)
	
print(" boucle for ".center(50, '-'))

print(result1, '\n')
rien = input('"Entree"')
result2 = [i+3 for i in range(6)]
print(" forme 1 ".center(50, '-'))
print(result2)



2. Utilisez une liste en compréhension pour ajouter 3 à chaque élément d’une liste d’entiers de 0 à 5, mais seulement si l’élément est supérieur ou égal à 2.

# -*- coding: UTF-8 -*-
"""Liste en intension.
Forme 2.
"""
# programme principal --------------------------------
result3 = []
for i in range(6):
	if i >= 2:
		result3.append(i+3)
		
print(" boucle for ".center(50, '-'))
print(result3, '\n')
rien = input('"Entree"')

result4 = [i+3 for i in range(6) if i >= 2]
print(" forme 2 ".center(50, '-'))
print(result4)


3. Utilisez une liste en compréhension pour obtenir la liste ['ad', 'ae', 'bd', 'be','cd', 'ce'] à partir des chaînes "abc" et "de".
Indication : utilisez deux boucles for imbriquées.

# -*- coding: UTF-8 -*-
"""Liste en intension.
Forme 3.
"""
# programme principal --------------------------
result5 = []
for i in "abc":
	for j in "de":
		result5.append(i+j)

print(" boucle for ".center(50, '-'))
print(result5, '\n')
rien = input('"Entree"')

result6 = [i+j for i in "abc" for j in "de"]
print(" forme 3 ".center(50, '-'))
print(result6)


4. Utilisez une liste en compréhension pour calculer la somme d’une liste d’entiers de 0 à 9.

# -*- coding: UTF-8 -*-
"""Liste en intension.
Calcul d'une somme.
"""
# programme principal --------------------
s1 = 0
for i in range(10):
	s1 = s1 + i

print(" somme (boucle for) ".center(50, '-'))
print("somme =", s1, '\n')
rien = input('"Entree"')

s2 = sum([i for i in range(10)])
print(" somme (liste en intension) ".center(50, '-'))
print("somme =", s2)


LES ENSEMBLES

1. Définir deux ensembles (sets) : X = {a,b,c,d} et Y = {s,b,d}, puis affichez les résultats suivants :
– les ensembles initiaux ;
– le test d’appartenance de l’élément 'c' à X ;
– le test d’appartenance de l’élément 'a' à Y ;
– les ensembles X-Y et Y-X ;
– l’ensemble X U Y (union) ;
– l’ensemble X inter Y (intersection).


# -*- coding: UTF-8 -*-
"""Les ensembles en Python.
"""
# programme principal -----------------------
X = set('abcd')
Y = set('sbds')
print(" ensembles de depart ".center(50, '-'))
print("X =", X)
print("Y =", Y)

rien = input('"Entree"')
print(" appartenance ".center(50, '-'))
print("'c' appartient a X ?", 'c' in X)
print("'a' appartient a Y ?", 'a' in Y)

rien = input('"Entree"')
print(" difference ".center(50, '-'))
print("X - Y :", X - Y)
print("Y - X :", Y - X)

rien = input('"Entree"')
print(" union ".center(50, '-'))
print("X | Y :", X | Y)

rien = input('"Entree"')
print(" intersection ".center(50, '-'))
print("X & Y :", X & Y)



PILES ET FILES

1. Implémentez une pile LIFO avec une liste.
Pour cela, définir trois fonctions :
pile : qui retourne une pile à partir d’une liste variable d’éléments passés en paramètre ;

empile : empile un élément en « haut » de la pile ;
depile : dépile un élément du « haut » de la pile.



# -*- coding: UTF-8 -*-
"""Implementation d'une pile LIFO avec une liste."""
# fonctions
def pile(*args):
	p = []
	if not args:
		return p
		
	for elem in args:
		p.append(elem)
		
	return list(p)

def empile(p, a):
	p.append(a)

def depile(p):
	try:
		return p.pop()
	except:
		print("La pile est vide !")



# programme principal ------------------
print(" Pile initiale ".center(50, '-'))
lifo = pile(5, 8, 9)
print("lifo :", lifo, '\n')

rien = input('"Entree"')
print(" Empilage ".center(50, '-'))
empile(lifo, 11)
print("lifo :", lifo, '\n')

rien = input('Entree"')
print(" Depilages ".center(50, '-'))
for i in range(5):
	depile(lifo)
	print("lifo :", lifo)



2. Implémentez une queue FIFO avec une liste.On Supposera que la file est une liste initialement vide déclarée globalement et que les différents opérations à programmer sont :

L'ajout   : Fonction enfiler(val)
Suppresion : Fonction defiler()
Tester si la file est vide : Fonction estVide()
Affichage du contenu de la file : Fonction affiche()
	

file=[] # une file déclaré globalement
 
def enfiler(val) :
    global file
    # Pour la suppression on utilisera l'opérateur Slicing
    file = file + [val]
 
def defiler():
    global file
    file= file[1:]
    
def estVide() :
    if file==[] :
        return True
 
    return False
    
def affiche() :
    for i in file :
        print('|  ',i,'  |') 
        print(' --------')
 
# Utilisation des fonctions 
print('est ce que la file est vide : ',estVide())
 
enfiler(5)
enfiler(7)
enfiler(8)
enfiler(12)
affiche()
 
print('est ce que la file est vide : ',estVide())
defiler()
 
print('Aprés la suppression :')
affiche()