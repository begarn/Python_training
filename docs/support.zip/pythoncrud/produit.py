from tkinter import *
from tkinter import ttk
import sqlite3
 
class Product:
	db_name = 'database.sqlite'
	
	def __init__(self, wind):
		self.wind = wind
		self.wind.title('IT products')
		
		# Créer un LabelFrame, ajoutez-y 2 Labels, 2 champs et 1 bouton Add record
		frame = LabelFrame(self.wind, text = 'Add new record')
		frame.grid(row = 0, column = 1)
		
		# Le nom du produit : 1er label et 1er champ
		Label(frame, text='Name:').grid(row=1, column = 1)
		self.name = Entry(frame)
		self.name.grid(row=1, column=2)
		
		# Le prix du produit : 2ème label et 2ème champ
		Label(frame, text='Price:').grid(row=2, column = 1)
		self.price = Entry(frame)
		self.price.grid(row=2, column=2)
		
		# Le bouton Add record
		ttk.Button(frame, text='Add record', command = self.adding).grid(row=3, column=2)
		self.message = Label(text='', fg='red')
		self.message.grid(row=3,column=0)
 
		# Maintenant, on va créer le widget Treeview de 2 colonnes name et Price (faire dir(ttk) ds console)
		self.tree = ttk.Treeview(height=10, column=2)
		self.tree.grid(row=4,column=0, columnspan=2)
		self.tree.heading('#0', text='Name', anchor=W)
		self.tree.heading(2, text='Price', anchor=W)
		
		# Ajoutons 2 boutons Delete et Edit
		ttk.Button(text='Delete record', command = self.deleting).grid(row=5, column=0)
		ttk.Button(text='Edit record', command = self.editing).grid(row=5, column=1)
		
		# Dans le constructeur de la classe, appeler la méthode viewing_records()  
		self.viewing_records()
	
	
	# Connexion à la base de données
	def run_query(self, query, parameters=()):
		with sqlite3.connect(self.db_name) as conn:
			cursor = conn.cursor()
			query_result = cursor.execute(query, parameters)
			conn.commit()
		return query_result

	
	# Méthode affichant les données à la base de données
	def viewing_records(self):
		# Nettoyer
		records = self.tree.get_children()
		for element in records:
			self.tree.delete(element)
			
		query = 'SELECT * FROM product ORDER BY name DESC'
		db_rows = self.run_query(query)
		
		for row in db_rows:
			self.tree.insert('', 0, text =  row[1], values = row[2])


	# Validation des saisies
	def validation(self):
		return len(self.name.get())  != 0 and len(self.price.get())  != 0

	# Ajouter la saisie à la base
	def adding(self):
		# Si les données sont valides
		if self.validation():
			query = 'INSERT INTO product VALUES(NULL,?,?)'
			parameters = (self.name.get(), self.price.get())
			self.run_query(query, parameters)
			
			# Message de succès
			self.message['text'] = 'Record {} added'.format(self.name.get())
			
			# Effacer les data s'il y en a (pour afficher les nouvelles)
			self.name.delete(0, END)
			self.price.delete(0, END)
		else:
			self.message['text'] = 'name field or price fiel is empty'
		
		# Visualiser les données
		self.viewing_records();


	# Supprimer les données
	def deleting(self):
		# Effacer le message
		self.message['text'] = ''
		
		# Sélection d'une ligne
		try:
			self.tree.item(self.tree.selection())['text']
		except indexError as e:
			self.message['text'] = 'Please select a record!'
		
		# Effacer le message
		self.message['text'] = ''
		
		# Requête SQL et exécution
		name = self.tree.item(self.tree.selection())['text']
		query = 'DELETE FROM product WHERE name = ?'
		self.run_query(query, (name, ))
		
		# Le message de succès
		self.message['text'] = 'Record {} deleted'.format(self.name)
		
		# Visualiser les données
		self.viewing_records();


	# Modifier les données : la fenêtre de modification
	def editing(self):
		# Effacer le message
		self.message['text'] = ''
		
		# Sélection d'une ligne (l'index)
		try:
			self.tree.item(self.tree.selection())['values'][0]
		except indexError as e:
			self.message['text'] = 'Please select a record!'

		# Requête SQL et exécution
		name = self.tree.item(self.tree.selection())['text']
		old_price = self.tree.item(self.tree.selection())['values'][0]
		
		# la fenêtre d'édition
		self.edit_wind = Toplevel()
		self.edit_wind.title('Editing')

		# Label et valeur de l'ancien nom de produit
		Label(self.edit_wind, text='Old name:').grid(row=0, column=1)
		var_name = StringVar(self.edit_wind, value=name)
		Entry(self.edit_wind, textvariable = var_name, state='readonly').grid(row=0, column=2)
		
		# Label et valeur de le nouveau nom de produit
		Label(self.edit_wind, text='New name:').grid(row=1, column=1)
		new_name = Entry(self.edit_wind)
		new_name.grid(row=1, column=2)
		
		# Label et valeur de l'ancien price de produit
		Label(self.edit_wind, text='Old price:').grid(row=2, column=1)
		var_price = DoubleVar(self.edit_wind, value=old_price)
		Entry(self.edit_wind, textvariable = var_price, state='readonly').grid(row=2, column=2)

		# Label et valeur de le nouveau price de produit
		Label(self.edit_wind, text='New price:').grid(row=3, column=1)
		new_price = Entry(self.edit_wind)
		new_price.grid(row=3,column=2)	
		
		# Bouton pour sauvegarder les changements, avec une commande 
		# sous forme de fonction lambda
		Button(self.edit_wind, text = 'Save changes', command=lambda:self.edit_records(new_name.get(), name, new_price.get(), old_price)).grid(row=4, column=2, sticky=W)
		
		# Loop sur la fenêtre d'édition
		self.edit_wind.mainloop()

		
	# Modifier les données : le traitement
	def edit_records(self, new_name, name, new_price, old_price):
		# Requêtes SQL
		query  = 'UPDATE product SET name=?, price=? WHERE name=? AND price=?'
		parameters = (new_name, new_price, name, old_price)
		
		# Exécuter la requête
		self.run_query(query, parameters)
		
		# Détruire la fenêtre d'édition
		self.edit_wind.destroy()
		
		# Message de succès
		self.message['text'] = 'Record {} changed'.format(self.name)
		
		# Afficher les données
		self.viewing_records()


# Programme principal
if __name__ == '__main__':
	wind = Tk()
	application = Product(wind)
	wind.mainloop()