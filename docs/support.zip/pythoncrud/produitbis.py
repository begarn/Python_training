from tkinter import *
from tkinter import ttk
import sqlite3
 
class Product:
	db_name = 'database.sqlite'
	
	def __init__(self, wind):
		self.wind = wind
		self.wind.title('Produits')
		
		# Créer un LabelFrame, ajoutez-y 2 Labels, 2 champs et 1 bouton Add record
		frame = LabelFrame(self.wind, text = 'Ajouter un produit')
		frame.grid(row = 0, column = 1)
		
		# Le nom du produit : 1er label et 1er champ
		Label(frame, text='Nom:').grid(row=1, column = 1)
		self.nom = Entry(frame)
		self.nom.grid(row=1, column=2)
		
		# Le prix du produit : 2ème label et 2ème champ
		Label(frame, text='Prix:').grid(row=2, column = 1)
		self.prix = Entry(frame)
		self.prix.grid(row=2, column=2)
		
		# Le bouton Add record
		ttk.Button(frame, text='Ajouter le produit', command = self.addProduct).grid(row=3, column=2)
		self.message = Label(text='', fg='red')
		self.message.grid(row=3,column=0)
 
		# Maintenant, on va créer le widget Treeview de 2 colonnes name et Price (faire dir(ttk) ds console)
		self.tree = ttk.Treeview(height=10, column=2)
		self.tree.grid(row=4,column=0, columnspan=2)
		self.tree.heading('#0', text='Nom', anchor=W)
		self.tree.heading(2, text='Prix', anchor=W)
		
		# Ajoutons 2 boutons Delete et Edit
		ttk.Button(text='Supprimer le produit', command = self.deleteProduct).grid(row=5, column=0)
		ttk.Button(text='Editer le produit', command = self.editProduct).grid(row=5, column=1)
		
		# Dans le constructeur de la classe, appeler la méthode showRecords()  
		self.showRecords()
	
	
	# Connexion à la base de données : renvoi le resultat
	def getResult(self, query, parameters=()):
		with sqlite3.connect(self.db_name) as conn:
			cursor = conn.cursor()
			query_result = cursor.execute(query, parameters)
			conn.commit()
		return query_result

	
	# Méthode affichant les données à la base de données
	def showRecords(self):
		# Nettoyer
		records = self.tree.get_children()
		for element in records:
			self.tree.delete(element)
			
		query = 'SELECT * FROM produit ORDER BY nom DESC'
		db_rows = self.getResult(query)
		
		# Fetch
		for row in db_rows:
			self.tree.insert('', 0, text =  row[1], values = row[2])


	# Validation des saisies
	def validation(self):
		return len(self.nom.get())  != 0 and len(self.prix.get())  != 0

	# Ajouter la saisie à la base
	def addProduct(self):
		# Si les données sont valides
		if self.validation():
			query = 'INSERT INTO produit VALUES(NULL,?,?)'
			parameters = (self.nom.get(), self.prix.get())
			self.getResult(query, parameters)
			
			# Message de succès
			self.message['text'] = 'Produit {} ajouté'.format(self.nom.get())
			
			# Effacer les data s'il y en a (pour afficher les nouvelles)
			self.nom.delete(0, END)
			self.prix.delete(0, END)
		else:
			self.message['text'] = 'Champ nom ou prix vide'
		
		# Visualiser les données
		self.showRecords();


	# Supprimer les données
	def deleteProduct(self):
		# Effacer le message
		self.message['text'] = ''
		
		# Sélection d'une ligne
		try:
			self.tree.item(self.tree.selection())['text']
		except indexError as e:
			self.message['text'] = 'Veuillez choisir un produit!'
		
		# Effacer le message
		self.message['text'] = ''
		
		# Requête SQL et exécution
		nom = self.tree.item(self.tree.selection())['text']
		query = 'DELETE FROM produit WHERE nom = ?'
		self.getResult(query, (nom, ))
		
		# Le message de succès
		self.message['text'] = 'produit {} supprimé'.format(self.nom)
		
		# Visualiser les données
		self.showRecords();


	# Modifier les données : la fenêtre de modification
	def editProduct(self):
		# Effacer le message
		self.message['text'] = ''
		
		# Sélection d'une ligne (l'index)
		try:
			self.tree.item(self.tree.selection())['values'][0]
		except indexError as e:
			self.message['text'] = 'Veuillez choisir un produit!'

		# Requête SQL et exécution
		nom = self.tree.item(self.tree.selection())['text']
		ancien_prix = self.tree.item(self.tree.selection())['values'][0]
		
		# la fenêtre d'édition
		self.edit_wind = Toplevel()
		self.edit_wind.title('Editer le produit')

		# Label et valeur de l'ancien nom de produit
		Label(self.edit_wind, text='Ancien nom:').grid(row=0, column=1)
		var_nom = StringVar(self.edit_wind, value=nom)
		Entry(self.edit_wind, textvariable = var_nom, state='readonly').grid(row=0, column=2)
		
		# Label et valeur de le nouveau nom de produit
		Label(self.edit_wind, text='Nouveau nom:').grid(row=1, column=1)
		nouveau_nom = Entry(self.edit_wind)
		nouveau_nom.grid(row=1, column=2)
		
		# Label et valeur de l'ancien prix de produit
		Label(self.edit_wind, text='Ancien prix:').grid(row=2, column=1)
		var_prix = DoubleVar(self.edit_wind, value=ancien_prix)
		Entry(self.edit_wind, textvariable = var_prix, state='readonly').grid(row=2, column=2)

		# Label et valeur de le nouveau prix de produit
		Label(self.edit_wind, text='Nouveau prix:').grid(row=3, column=1)
		nouveau_prix = Entry(self.edit_wind)
		nouveau_prix.grid(row=3,column=2)	
		
		# Bouton pour sauvegarder les changements, avec une commande 
		# sous forme de fonction lambda
		Button(self.edit_wind, text = 'Modifier', command=lambda:self.editRecord(nouveau_nom.get(), nom, nouveau_prix.get(), ancien_prix)).grid(row=4, column=2, sticky=W)
		
		# Loop sur la fenêtre d'édition
		self.edit_wind.mainloop()

		
	# Modifier les données : le traitement
	def editRecord(self, nouveau_nom, nom, nouveau_prix, ancien_prix):
		# Requêtes SQL
		query  = 'UPDATE produit SET nom=?, prix=? WHERE nom=? AND prix=?'
		parameters = (nouveau_nom, nouveau_prix, nom, ancien_prix)
		
		# Exécuter la requête
		self.getResult(query, parameters)
		
		# Détruire la fenêtre d'édition
		self.edit_wind.destroy()
		
		# Message de succès
		self.message['text'] = 'Produit {} modifié'.format(self.nom)
		
		# Afficher les données
		self.showRecords()


# Programme principal
if __name__ == '__main__':
	wind = Tk()
	application = Product(wind)
	wind.mainloop()